-- Phase 1: Final relational schema (MySQL 8.0.16+). Do not change after approval.
CREATE DATABASE IF NOT EXISTS payroll_db;
USE payroll_db;

CREATE TABLE department (
  dept_id    INT AUTO_INCREMENT PRIMARY KEY,
  dept_name  VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE employee (
  emp_id       INT AUTO_INCREMENT PRIMARY KEY,
  full_name    VARCHAR(100) NOT NULL,
  email        VARCHAR(120) NOT NULL UNIQUE,
  dept_id      INT NOT NULL,
  designation  VARCHAR(60) NOT NULL,
  join_date    DATE NOT NULL,
  status       ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  FOREIGN KEY (dept_id) REFERENCES department(dept_id)
);

CREATE TABLE salary (
  salary_id       INT AUTO_INCREMENT PRIMARY KEY,
  emp_id          INT NOT NULL,
  basic           DECIMAL(10,2) NOT NULL CHECK (basic > 0),
  hra             DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (hra >= 0),
  allowances      DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (allowances >= 0),
  effective_from  DATE NOT NULL,
  effective_to    DATE NULL,
  CHECK (effective_to IS NULL OR effective_to >= effective_from),
  FOREIGN KEY (emp_id) REFERENCES employee(emp_id)
);

CREATE TABLE attendance (
  att_id     INT AUTO_INCREMENT PRIMARY KEY,
  emp_id     INT NOT NULL,
  att_date   DATE NOT NULL,
  check_in   TIME NULL,
  check_out  TIME NULL,
  status     ENUM('PRESENT','ABSENT','HALF_DAY','ON_LEAVE') NOT NULL,
  UNIQUE (emp_id, att_date),
  CHECK (check_out IS NULL OR check_in IS NULL OR check_out > check_in),
  FOREIGN KEY (emp_id) REFERENCES employee(emp_id)
);

CREATE TABLE leave_type (
  leave_type_id      INT AUTO_INCREMENT PRIMARY KEY,
  type_name          VARCHAR(40) NOT NULL UNIQUE,
  max_days_per_year  INT NOT NULL CHECK (max_days_per_year >= 0),
  is_paid            BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE leave_request (
  leave_id       INT AUTO_INCREMENT PRIMARY KEY,
  emp_id         INT NOT NULL,
  leave_type_id  INT NOT NULL,
  start_date     DATE NOT NULL,
  end_date       DATE NOT NULL,
  status         ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  CHECK (end_date >= start_date),
  FOREIGN KEY (emp_id) REFERENCES employee(emp_id),
  FOREIGN KEY (leave_type_id) REFERENCES leave_type(leave_type_id)
);

CREATE TABLE payroll (
  payroll_id    INT AUTO_INCREMENT PRIMARY KEY,
  emp_id        INT NOT NULL,
  salary_id     INT NOT NULL,
  pay_month     DATE NOT NULL,
  working_days  INT NOT NULL,
  days_paid     DECIMAL(4,1) NOT NULL,
  gross_pay     DECIMAL(12,2) NOT NULL,
  tax_deducted  DECIMAL(12,2) NOT NULL CHECK (tax_deducted >= 0),
  net_pay       DECIMAL(12,2) NOT NULL CHECK (net_pay >= 0),
  generated_on  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (emp_id, pay_month),
  FOREIGN KEY (emp_id) REFERENCES employee(emp_id),
  FOREIGN KEY (salary_id) REFERENCES salary(salary_id)
);

CREATE TABLE app_user (
  user_id        INT AUTO_INCREMENT PRIMARY KEY,
  username       VARCHAR(50) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  role           ENUM('HR_ADMIN','EMPLOYEE') NOT NULL,
  emp_id         INT NULL UNIQUE,
  FOREIGN KEY (emp_id) REFERENCES employee(emp_id)
);
