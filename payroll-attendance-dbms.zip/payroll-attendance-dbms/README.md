# Payroll & Attendance System (DBMS Capstone)

Full-lifecycle DBMS application for a mid-sized IT firm: data modeling, procedural SQL,
reporting and optimization, security, and a role-based CLI.

**Stack:** MySQL 8, Python 3 (CLI)

## Project status

| Phase | Deliverable | Status |
|---|---|---|
| 1 | ER diagram, 3NF normalization, schema (`sql/01_schema.sql`) | Done |
| 2 | Functions, procedures, triggers, sample data | To do |
| 3 | Reports, indexes, EXPLAIN before/after | To do |
| 4 | RBAC, transactions, test cases | To do |
| 5 | Role-based CLI, screenshots, final report | To do |

## Setup

```
mysql -u root -p < sql/01_schema.sql
```

## Structure

- `sql/`   schema, procedures, triggers, data, reports, security scripts
- `app/`   Python CLI
- `tests/` test cases and recorded results
- `docs/`  ER diagram, normalization notes, screenshots, final report

## Design notes

- Late marks are derived (`check_in` later than office start), not stored.
- `payroll` is a deliberate snapshot so history survives later salary revisions.
- `UNIQUE(emp_id, att_date)` blocks duplicate attendance entries.
